# OctoklipscreenBridge - Javított Verzió

Ez az összeállítás tartalmazza az **OctoklipscreenBridge** OctoPrint pluginjének összes szükséges javítását az OctoPrinttel való teljes kompatibilitáshoz.

## 📋 Mit Tartalmaz Ez Az Csomag

### Javított Fájlok

1. **`setup.py`** - Robusztus telepítési konfiguráció
   - Python verzió ellenőrzése (3.7+)
   - Informatív error handling
   - OctoPrint setuptools import

2. **`octoklipscreen_bridge/__init__.py`** - Teljes plugin implementáció
   - OctoPrint plugin alaposztály kiterjesztés
   - MQTT kliens integráció
   - Settings kezelés
   - Event handling

3. **`octoklipscreen_bridge/templates/settings.html`** - Grafikus beállítások
   - MQTT host, port, username, password konfigurálása
   - Enable/disable toggle
   - Inline help szövegek

### Új Fájlok

4. **`pyproject.toml`** - Modern Python packaging
   - PEP 517/518 kompatibilitás
   - Metaadatok definíciója
   - Automatikus függőség feloldás

5. **`MANIFEST.in`** - Csomagfájl definíció
   - Sablonok és statikus fájlok belefoglalása
   - Cache fájlok kizárása

6. **`INSTALLATION_GUIDE_HU.md`** - Teljes telepítési útmutató (magyarul)
   - Szükséges előfeltételek
   - Lépésről-lépésre telepítési útmutató
   - MQTT Broker beállítása
   - Hibaelhárítási útmutató

7. **`FIXES_APPLIED.md`** - Javítások leírása
   - Milyen problémákat oldottak meg
   - Hogyan kerülendő a közös problémák
   - Érvényesítési lista

8. **`diagnose.sh`** - Diagnosztikai eszköz
   - Automatikus problémaazonosítás
   - Python/OctoPrint/MQTT ellenőrzése
   - Hasznos tanácsok a problémák megoldásához

## 🚀 Gyors Kezdés

### 1. Előfeltételek

```bash
# Virtual environment aktiválása
source ~/oprint/bin/activate

# Python verzió ellenőrzése
python --version  # >= 3.7 szükséges

# pip/setuptools frissítése
pip install --upgrade pip setuptools wheel
```

### 2. Fájlok Cseréje a Repositoryban

```bash
# Menj a plugin könyvtárba
cd ~/OctoklipscreenBridge  # vagy ahol a plugin van

# 1. Fájlok cseréje
cp setup_fixed.py setup.py
cp pyproject.toml .
cp MANIFEST.in .

# 2. Plugin könyvtár előkészítése
mkdir -p octoklipscreen_bridge/templates

# 3. Plugin __init__.py cseréje
cp plugin_init.py octoklipscreen_bridge/__init__.py

# 4. Settings HTML másolása
cp settings.html octoklipscreen_bridge/templates/

# 5. Dokumentáció másolása
cp INSTALLATION_GUIDE_HU.md .
cp FIXES_APPLIED.md .
cp diagnose.sh .
chmod +x diagnose.sh
```

### 3. Telepítés

```bash
# Virtual environment aktiválása
source ~/oprint/bin/activate

# Plugin telepítése fejlesztői módban
cd ~/OctoklipscreenBridge
pip install -e .

# OctoPrint újraindítása
sudo systemctl restart octoprint

# Naplók ellenőrzése
tail -50 ~/.octoprint/logs/octoprint.log | grep -i octoklipscreen
```

### 4. MQTT Broker Telepítése (ha nincs)

```bash
sudo apt update
sudo apt install mosquitto mosquitto-clients -y
sudo systemctl enable mosquitto
sudo systemctl start mosquitto
```

### 5. Konfigurálás OctoPrint-ben

1. **Serial Logging Bekapcsolása** (KÖTELEZŐ!)
   - OctoPrint → Settings → Features
   - ✓ Log communication to serial.log
   - Save

2. **Plugin Beállítása**
   - OctoPrint → Settings → OctoklipscreenBridge
   - MQTT Host: `localhost` (vagy az MQTT szerver IP-je)
   - MQTT Port: `1883`
   - MQTT Username/Password: (ha szükséges)
   - ✓ Enable MQTT Bridge
   - Save

## 🔍 Problémamegoldás

### Automata Diagnosztika

```bash
# Futtasd a diagnosztikai script-et
./diagnose.sh

# Vagy részletesen:
bash diagnose.sh 2>&1 | tee diagnose.log
```

### Gyakori Problémák

**"ModuleNotFoundError: No module named 'paho.mqtt'"**
```bash
source ~/oprint/bin/activate
pip install 'paho-mqtt>=1.5.0,<3.0'
sudo systemctl restart octoprint
```

**"Could not import OctoPrint's setuptools"**
```bash
source ~/oprint/bin/activate
pip install -e .
sudo systemctl restart octoprint
```

**"MQTT csatlakozási hiba"**
```bash
# Mosquitto ellenőrzése
sudo systemctl status mosquitto

# Port ellenőrzése
netstat -tuln | grep 1883

# Tesztelés
mosquitto_pub -h localhost -t "test" -m "Hello"
```

**"Serial log üres"**
- Engedélyezd: OctoPrint Settings → Features → Serial Logging
- Csatlakoztass-e printert?

## 📚 Dokumentáció

| Fájl | Tartalom |
|------|----------|
| `INSTALLATION_GUIDE_HU.md` | Teljes telepítési és konfigurálási útmutató |
| `FIXES_APPLIED.md` | A javítások részletes leírása |
| `diagnose.sh` | Automata diagnosztikai eszköz |
| `setup.py` | Telepítési konfiguráció |
| `pyproject.toml` | Modern Python packaging |

## ✅ Kompatibilitási Checklist

- [x] Python 3.7+ támogatás
- [x] OctoPrint 1.4.0+ támogatás
- [x] Helyes setuptools import
- [x] paho-mqtt integráció (1.5.0+)
- [x] Grafikus beállítások UI
- [x] MQTT kommunikáció
- [x] Event handling (nyomtatási események)
- [x] Automatic reconnect
- [x] Graceful shutdown
- [x] Logging és debug

## 🐛 Teszt Parancsok

```bash
# Python szintaxis ellenőrzés
python -m py_compile setup.py

# Import tesztelés
python -c "from octoklipscreen_bridge import OctoklipscreenBridgePlugin; print('OK')"

# MQTT tesztelés
mosquitto_sub -t "octoprint/serial" &
# Másik terminálon:
mosquitto_pub -t "octoprint/serial" -m "test message"
```

## 📞 Támogatás

Ha továbbra sem működik:

1. **Futtasd a diagnosztikai script-et:**
   ```bash
   ./diagnose.sh 2>&1 | tee diagnose.log
   ```

2. **Gyűjtsd össze az információkat:**
   - OctoPrint verzió
   - Python verzió
   - Naplófájlok (`~/.octoprint/logs/octoprint.log`)
   - diagnose.log kimenet

3. **Nyiss egy GitHub Issue-t:**
   https://github.com/karolyia79/OctoklipscreenBridge/issues

## 📝 Verzió Történet

**0.4.2-fixed:**
- ✨ Robusztus error handling
- ✨ Teljes plugin implementáció
- ✨ Modern packaging (pyproject.toml)
- ✨ Grafikus beállítások UI
- ✨ Teljes dokumentáció
- ✨ Diagnosztikai eszköz

## 📜 Licenc

AGPLv3 - Lásd a LICENSE fájlt

---

**Utolsó frissítés:** 2026. augusztus 8.
**Javasolt verzió:** OctoPrint 1.4.0+, Python 3.7+

## 🎯 Következő Lépések

1. ✅ Alkalmazd az összes javítást
2. ✅ Telepítsd a plugin-t: `pip install -e .`
3. ✅ Indítsd újra az OctoPrint-et
4. ✅ Engedélyezd a serial logging-ot
5. ✅ Konfiguráld az MQTT beállításokat
6. ✅ Tesztelj egy MQTT üzenet küldéssel

**Türelmes problémamegoldást! 🚀**
