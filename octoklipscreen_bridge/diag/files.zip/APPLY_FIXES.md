# OctoklipscreenBridge Javítások Alkalmazása - Lépésenkénti Útmutató

## 🎯 Cél

Az OctoklipscreenBridge OctoPrint plugin teljes kompatibilitásának biztosítása a Python 3.7+ és OctoPrint 1.4.0+ verzióival.

## ⚠️ Előzetes Figyelmeztetés

- **Backup**: Készítsd el a jelenlegi beállításaidat!
- **SSH hozzáférés**: SSH-val kell tudnod kapcsolódni az OctoPrint géphez
- **sudo hozzáférés**: Szükséges a rendszer parancsokhoz

---

## 📦 1. lépés: Javított Fájlok Letöltése

Két lehetőséged van:

### Opció A: GitHub Patch Alkalmazása

```bash
cd ~/OctoklipscreenBridge
git fetch origin
git checkout main

# Vagy ha már módosított verziód van:
git stash  # Mentsd a módosításaid
git pull origin main
```

### Opció B: Fájlok Manuális Másolása

1. Másold le az alábbi fájlokat:
   - `setup.py` → `setup_fixed.py`
   - `octoklipscreen_bridge/__init__.py` → `plugin_init.py`
   - `octoklipscreen_bridge/templates/settings.html`
   - `pyproject.toml`
   - `MANIFEST.in`

2. SSH-n keresztül másolj:
```bash
# Helyi gépről
scp setup_fixed.py pi@octopi.local:~/OctoklipscreenBridge/
scp plugin_init.py pi@octopi.local:~/OctoklipscreenBridge/
scp settings.html pi@octopi.local:~/OctoklipscreenBridge/
# stb.
```

---

## 🔧 2. lépés: Fájlok Helyét a Plugin Könyvtárban

SSH-val csatlakozz:
```bash
ssh pi@octopi.local
```

Navigálj a plugin könyvtárba:
```bash
cd ~/OctoklipscreenBridge

# Vagy ha máshol van:
find ~ -name "octoklipscreen_bridge" -type d
```

Ellenőrizd a jelenlegi szerkezetet:
```bash
ls -la
# Kimenet:
# -rw-r--r-- setup.py
# -rw-r--r-- README.md
# drwxr-xr-x octoklipscreen_bridge/

ls -la octoklipscreen_bridge/
# Kimenet:
# -rw-r--r-- __init__.py (RÉGI - helyettesítendő!)
# -rw-r--r-- MANIFEST.in
# drwxr-xr-x templates/
```

---

## 📝 3. lépés: Fájlok Cseréje

### 3.1 setup.py Cseréje

```bash
# Backup az eredeti fájlról
cp setup.py setup.py.backup

# Az új fájllal helyettesítés
# (másolj be az új setup_fixed.py tartalmát, vagy:)
cat > setup.py << 'EOF'
# coding=utf-8

"""
OctoPrint plugin setup configuration with improved compatibility...
"""

# [Az új setup.py tartalma...]
EOF
```

### 3.2 __init__.py Cseréje

```bash
# Backup az eredeti fájlról
cp octoklipscreen_bridge/__init__.py octoklipscreen_bridge/__init__.py.backup

# Az új fájllal helyettesítés
cat > octoklipscreen_bridge/__init__.py << 'EOF'
# coding=utf-8
"""
OctoklipscreenBridge - OctoPrint plugin...
"""

# [Az új __init__.py tartalma...]
EOF
```

### 3.3 settings.html Létrehozása

```bash
# Könyvtár ellenőrzése/létrehozása
mkdir -p octoklipscreen_bridge/templates

# Fájl létrehozása
cat > octoklipscreen_bridge/templates/settings.html << 'EOF'
<div class="control-group">
    ...
    <!-- [Az új settings.html tartalma...] -->
</div>
EOF
```

### 3.4 pyproject.toml Létrehozása

```bash
cat > pyproject.toml << 'EOF'
[build-system]
requires = ["setuptools>=45", "wheel"]
build-backend = "setuptools.build_meta"

# [Az új pyproject.toml tartalma...]
EOF
```

### 3.5 MANIFEST.in Cseréje

```bash
# Backup
cp MANIFEST.in MANIFEST.in.backup

cat > MANIFEST.in << 'EOF'
recursive-include octoklipscreen_bridge/templates *
recursive-include octoklipscreen_bridge/static *
include octoklipscreen_bridge/__init__.py
include setup.py
include README.md
include LICENSE
global-exclude __pycache__
global-exclude *.pyc
global-exclude *.pyo
global-exclude .DS_Store
EOF
```

---

## ✅ 4. lépés: Telepítés Tesztelése

```bash
# 1. Virtual environment aktiválása
source ~/oprint/bin/activate

# 2. Python verzió ellenőrzése
python --version  # >= 3.7 szükséges

# 3. Szintaxis ellenőrzés
python -m py_compile setup.py

# 4. Import tesztelés
cd ~/OctoklipscreenBridge
python -c "import sys; sys.path.insert(0, '.'); from octoklipscreen_bridge import *; print('Import OK')"

# 5. setuptools ellenőrzés
python -c "import octoprint_setuptools; print('OctoPrint setuptools OK')"
```

Ha van hiba, ellenőrizd a fájl tartalmát!

---

## 🔄 5. lépés: Függőségek Telepítése

```bash
# Virtual environment aktiválása
source ~/oprint/bin/activate

# Függőségek telepítése
pip install --upgrade pip setuptools wheel
pip install 'paho-mqtt>=1.5.0,<3.0'

# Ellenőrzés
python -c "import paho.mqtt.client; print('MQTT OK')"
```

---

## 📦 6. lépés: Plugin Telepítése

```bash
# Virtual environment aktiválása
source ~/oprint/bin/activate

# Fejlesztői módban telepítés
cd ~/OctoklipscreenBridge
pip install -e .

# Vagy tiszta telepítés
pip uninstall octoklipscreen_bridge -y
pip install -e .
```

Ha hiba van:
```bash
# Naplók megtekintése
pip install -e . -v

# Vagy szintaxis ellenőrzés
python setup.py check
```

---

## 🔄 7. lépés: OctoPrint Újraindítása

```bash
# Szolgáltatás újraindítása
sudo systemctl restart octoprint

# Ellenőrzés
sudo systemctl status octoprint

# Naplók megtekintése (30 másodpercet várakozz)
sleep 30
tail -50 ~/.octoprint/logs/octoprint.log | grep -i octoklipscreen
```

Sikeresnek kell lennie:
```
INFO ... OctoklipscreenBridge plugin started
```

---

## 🔐 8. lépés: Serial Logging Bekapcsolása

1. **Nyisd meg az OctoPrint weboldalt**: `http://octopi.local:5000`
2. **Settings** (Beállítások) → **Features**
3. **Serial Logging** szakasz
4. **✓ Log communication to serial.log** pipálása
5. **Save**

Ellenőrzés:
```bash
tail ~/.octoprint/logs/serial.log
# Szoros kommunikáció üzeneteinek kell megjelennie
```

---

## ⚙️ 9. lépés: MQTT Konfigurálása

### 9.1 Mosquitto Telepítése (ha nincs)

```bash
sudo apt update
sudo apt install mosquitto mosquitto-clients -y
sudo systemctl enable mosquitto
sudo systemctl start mosquitto
```

Tesztelés:
```bash
mosquitto_pub -t "test" -m "Hello"
```

### 9.2 Plugin Beállítása OctoPrint-ben

1. **Settings** → **OctoklipscreenBridge**
2. Kitöltsd az MQTT beállításokat:
   - **MQTT Host**: `localhost` (vagy IP)
   - **MQTT Port**: `1883`
   - **MQTT Username**: (ha szükséges, pl. "mosquitto")
   - **MQTT Password**: (ha szükséges)
   - **MQTT Topic**: `octoprint/serial`
3. **✓ Enable MQTT Bridge** pipálása
4. **Save**

---

## 🧪 10. lépés: Tesztelés

### MQTT Csatlakozás Tesztelése

Egy másik terminálban:
```bash
# Figyelj az üzenetekre
mosquitto_sub -t "octoprint/#" -v

# Másik terminálban: küldjön üzeneteket
mosquitto_pub -t "octoprint/serial" -m "Test message"
```

### OctoPrint Naplók

```bash
# Valós idejű naplózás
tail -f ~/.octoprint/logs/octoprint.log | grep octoklipscreen

# Vagy részletesen
tail -100 ~/.octoprint/logs/octoprint.log
```

Sikeres indítás:
```
INFO ... OctoklipscreenBridge plugin started
INFO ... Connecting to MQTT broker at localhost:1883
INFO ... Connected to MQTT broker
```

---

## 🆘 11. lépés: Hibaelhárítás

Ha nem működik, futtasd a diagnosztikai script-et:

```bash
# Ha még nincs: letöltés
wget https://github.com/karolyia79/OctoklipscreenBridge/raw/main/diagnose.sh
chmod +x diagnose.sh

# Futtatás
./diagnose.sh
```

Gyakori problémák:

| Hiba | Megoldás |
|------|----------|
| `ModuleNotFoundError: octoprint_setuptools` | `source ~/oprint/bin/activate` |
| `paho.mqtt not found` | `pip install 'paho-mqtt>=1.5.0,<3.0'` |
| MQTT connection refused | `sudo systemctl restart mosquitto` |
| Serial log üres | Engedélyezd a serial logging-ot az OctoPrint Settings-ben |
| Plugin nem jelenik meg | `sudo systemctl restart octoprint` |

---

## ✅ 12. lépés: Végső Ellenőrzés

```bash
# 1. Python verzió
python --version  # >= 3.7

# 2. OctoPrint futva
sudo systemctl status octoprint

# 3. MQTT broker futva
sudo systemctl status mosquitto

# 4. Plugin aktív
curl -s http://localhost:5000/api/plugin/octoklipscreen_bridge | python -m json.tool

# 5. Soros naplóban adatok
tail ~/.octoprint/logs/serial.log

# 6. MQTT üzenetek érkeznek
mosquitto_sub -t "octoprint/serial" &
```

---

## 📋 Telepítés Ellenőrzési Lista

- [ ] Fájlok letöltve és másolt
- [ ] setup.py frissítve
- [ ] __init__.py frissítve
- [ ] settings.html létrehozva
- [ ] pyproject.toml létrehozva
- [ ] MANIFEST.in frissítve
- [ ] Pip/setuptools frissítve
- [ ] paho-mqtt telepítve
- [ ] Plugin telepítve: `pip install -e .`
- [ ] OctoPrint újraindítva
- [ ] Serial logging bekapcsolva
- [ ] Mosquitto telepítve és futva
- [ ] MQTT beállítások kitöltve
- [ ] Beállítások mentve
- [ ] MQTT üzenetek tesztelve

---

## 🎉 Siker!

Ha az összes lépést követted, az OctoklipscreenBridge plugin most már fully kompatibilis az OctoPrinttel!

**Hibaelhárítás**: `./diagnose.sh` futtatása
**Naplók**: `tail -f ~/.octoprint/logs/octoprint.log`
**Támogatás**: https://github.com/karolyia79/OctoklipscreenBridge/issues

---

**Utolsó frissítés:** 2026. augusztus 8.
**Kompatibilitás:** OctoPrint 1.4.0+, Python 3.7+
